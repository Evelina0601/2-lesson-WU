for (let i = 10; i <= 50; i += 2) {
    console.log (i);
}