let i = 21;
while(i <= 67) {
    console.log(i);
    i = i + 2;
};