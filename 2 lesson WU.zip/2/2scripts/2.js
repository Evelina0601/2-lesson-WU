let user = {
    firstN: "Vasya",
    secondN: "Pupkin",
    age: 20,
    animal : true
};
console.log(user);