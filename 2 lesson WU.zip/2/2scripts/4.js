const fullName = (firstName, lastName) => {
    console.log(firstName+" "+lastName);
}
fullName('Vasya', 'Pupkin');
